import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Comparator;

class Process {
    int id, arrivalTime, burstTime, waitingTime, turnaroundTime;

    Process(int id, int arrivalTime, int burstTime) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
    }
}

public class SJFInterface extends JFrame {
    private JTextField txtArrivalTime;
    private JTextField txtBurstTime;
    private DefaultTableModel model;
    private Process[] processes;
    private int processCount = 0;

    public SJFInterface() {
        setTitle("SJF Scheduler");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Painel para entrada de dados
        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        inputPanel.add(new JLabel("Tempo de Chegada:"));
        txtArrivalTime = new JTextField();
        inputPanel.add(txtArrivalTime);

        inputPanel.add(new JLabel("Tempo de Burst:"));
        txtBurstTime = new JTextField();
        inputPanel.add(txtBurstTime);

        JButton btnAddProcess = new JButton("Adicionar Processo");
        inputPanel.add(btnAddProcess);

        JButton btnCalculate = new JButton("Calcular");
        inputPanel.add(btnCalculate);

        add(inputPanel, BorderLayout.NORTH);

        // Tabela para mostrar os processos e resultados
        String[] columns = {"ID", "Tempo de Chegada", "Tempo de Burst", "Tempo de Espera", "Tempo de Turnaround"};
        model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Ação para adicionar processos
        btnAddProcess.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addProcess();
            }
        });

        // Ação para calcular SJF
        btnCalculate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateSJF();
            }
        });
    }

    private void addProcess() {
        try {
            int arrivalTime = Integer.parseInt(txtArrivalTime.getText());
            int burstTime = Integer.parseInt(txtBurstTime.getText());
            Process process = new Process(++processCount, arrivalTime, burstTime);

            if (processes == null) {
                processes = new Process[10]; // máximo 10 processos para este exemplo
            }
            processes[processCount - 1] = process;

            model.addRow(new Object[]{process.id, process.arrivalTime, process.burstTime, "-", "-"});
            txtArrivalTime.setText("");
            txtBurstTime.setText("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, insira valores válidos!");
        }
    }

    private void calculateSJF() {
        if (processes == null || processCount == 0) {
            JOptionPane.showMessageDialog(this, "Nenhum processo adicionado!");
            return;
        }

        // Ordenar os processos por burst time
        Arrays.sort(processes, 0, processCount, Comparator.comparingInt((Process p) -> p.burstTime)
                .thenComparingInt(p -> p.arrivalTime));

        int currentTime = 0;
        double totalWaitingTime = 0;
        double totalTurnaroundTime = 0;

        for (int i = 0; i < processCount; i++) {
            Process process = processes[i];

            if (currentTime < process.arrivalTime) {
                currentTime = process.arrivalTime;
            }

            process.waitingTime = currentTime - process.arrivalTime;
            totalWaitingTime += process.waitingTime;

            process.turnaroundTime = process.waitingTime + process.burstTime;
            totalTurnaroundTime += process.turnaroundTime;

            currentTime += process.burstTime;

            // Atualizar tabela
            model.setValueAt(process.waitingTime, i, 3);
            model.setValueAt(process.turnaroundTime, i, 4);
        }

        JOptionPane.showMessageDialog(this, "Cálculos realizados!\nTempo médio de espera: " + (totalWaitingTime / processCount) +
                "\nTempo médio de turnaround: " + (totalTurnaroundTime / processCount));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SJFInterface frame = new SJFInterface();
            frame.setVisible(true);
        });
    }
}
